
@echo off
echo ========================================
echo AI图像识别系统启动脚本
echo ========================================
echo.

echo 正在检查Python环境...
python --version
if %errorlevel% neq 0 (
    echo 错误: 未找到Python环境，请先安装Python
    pause
    exit /b 1
)

echo.
echo 正在安装依赖包...
pip install -r requirements.txt

echo.
echo 正在启动后端服务...
echo 后端服务将在 http://localhost:5000 上运行
echo 前端页面将在浏览器中自动打开
echo.
echo 按Ctrl+C可以停止服务
echo.

cd backend
start "" python app.py
cd ..
echo 正在打开浏览器...
start "" "frontend/index.html"
echo 服务已启动，请勿关闭此窗口
echo 按任意键停止服务...
pause >nul
taskkill /f /im python.exe >nul 2>&1
