
from flask import Flask, render_template, request, jsonify
from flask_cors import CORS
import requests
import base64
import os

app = Flask(__name__, template_folder='../frontend')
CORS(app)  # 允许跨域请求

# API端点配置
API_ENDPOINTS = {
    'general': 'https://aip.baidubce.com/rest/2.0/image-classify/v2/advanced_general',
    'animal': 'https://aip.baidubce.com/rest/2.0/image-classify/v1/animal',
    'plant': 'https://aip.baidubce.com/rest/2.0/image-classify/v1/plant',
    'dish': 'https://aip.baidubce.com/rest/2.0/image-classify/v2/dish',
    'car': 'https://aip.baidubce.com/rest/2.0/image-classify/v1/car'
}

@app.route('/')
def index():
    """渲染主页"""
    return render_template('index.html')

@app.route('/api/get_token', methods=['POST'])
def get_token():
    """获取Access Token"""
    data = request.json
    api_key = data.get('api_key')
    secret_key = data.get('secret_key')

    if not api_key or not secret_key:
        return jsonify({'error': '请提供API Key和Secret Key'}), 400

    try:
        # 请求百度OAuth 2.0接口获取Access Token
        response = requests.post(
            'https://aip.baidubce.com/oauth/2.0/token',
            data={
                'grant_type': 'client_credentials',
                'client_id': api_key,
                'client_secret': secret_key
            }
        )

        result = response.json()

        if 'error' in result:
            return jsonify({
                'error': result.get('error_description', '获取Access Token失败')
            }), 400

        return jsonify({
            'access_token': result.get('access_token'),
            'expires_in': result.get('expires_in', 2592000)
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/recognize', methods=['POST'])
def recognize():
    """图像识别"""
    data = request.json
    access_token = data.get('access_token')
    endpoint = data.get('endpoint', 'general')
    image_data = data.get('image')

    if not access_token or not image_data:
        return jsonify({'error': '请提供Access Token和图片数据'}), 400

    if endpoint not in API_ENDPOINTS:
        return jsonify({'error': '无效的API端点'}), 400

    try:
        # 准备请求参数
        params = {
            'image': image_data,
            'baike_num': 3
        }

        # 请求百度图像识别API
        response = requests.post(
            f"{API_ENDPOINTS[endpoint]}?access_token={access_token}",
            data=params,
            headers={'Content-Type': 'application/x-www-form-urlencoded'}
        )

        result = response.json()

        if 'error_code' in result:
            return jsonify({
                'error': result.get('error_msg', '图像识别失败'),
                'error_code': result.get('error_code')
            }), 400

        return jsonify({
            'result': result.get('result', [])
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
