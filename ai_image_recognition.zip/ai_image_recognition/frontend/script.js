
// 获取DOM元素
const uploadArea = document.getElementById('upload-area');
const imageInput = document.getElementById('image-input');
const previewArea = document.getElementById('preview-area');
const previewImage = document.getElementById('preview-image');
const removeImageBtn = document.getElementById('remove-image');
const modelStatusText = document.getElementById('model-status');
const resultsDiv = document.getElementById('results');

// 存储当前图片和模型
let currentImage = null;
let model = null;

// 加载MobileNet模型
async function loadModel() {
    try {
        model = await mobilenet.load();
        modelStatusText.textContent = '模型加载成功！可以上传图片进行识别';
        modelStatusText.classList.add('success');
    } catch (error) {
        modelStatusText.textContent = '模型加载失败: ' + error.message;
        modelStatusText.classList.add('error');
    }
}

// 页面加载时加载模型
window.addEventListener('DOMContentLoaded', loadModel);

// 上传区域点击事件
uploadArea.addEventListener('click', () => {
    imageInput.click();
});

// 图片选择事件
imageInput.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = (event) => {
            currentImage = event.target.result;
            previewImage.src = currentImage;
            uploadArea.style.display = 'none';
            previewArea.style.display = 'block';
            
            // 如果模型已加载，自动进行识别
            if (model) {
                recognizeImage();
            }
        };
        reader.readAsDataURL(file);
    }
});

// 移除图片事件
removeImageBtn.addEventListener('click', () => {
    currentImage = null;
    imageInput.value = '';
    uploadArea.style.display = 'block';
    previewArea.style.display = 'none';
    resultsDiv.innerHTML = '';
});

// 拖拽上传事件
uploadArea.addEventListener('dragover', (e) => {
    e.preventDefault();
    uploadArea.style.backgroundColor = '#f8f9ff';
});

uploadArea.addEventListener('dragleave', () => {
    uploadArea.style.backgroundColor = '';
});

uploadArea.addEventListener('drop', (e) => {
    e.preventDefault();
    uploadArea.style.backgroundColor = '';
    
    const file = e.dataTransfer.files[0];
    if (file && file.type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onload = (event) => {
            currentImage = event.target.result;
            previewImage.src = currentImage;
            uploadArea.style.display = 'none';
            previewArea.style.display = 'block';
            
            // 如果模型已加载，自动进行识别
            if (model) {
                recognizeImage();
            }
        };
        reader.readAsDataURL(file);
    }
});

// 图像识别函数
async function recognizeImage() {
    if (!currentImage || !model) {
        return;
    }
    
    try {
        // 使用MobileNet模型进行识别
        const predictions = await model.classify(previewImage);
        
        if (predictions && predictions.length > 0) {
            displayResults(predictions);
        } else {
            resultsDiv.innerHTML = '<div class="result-item">未识别到任何内容</div>';
        }
    } catch (error) {
        resultsDiv.innerHTML = `<div class="result-item">识别失败: ${error.message}</div>`;
    }
}

// 显示识别结果
function displayResults(predictions) {
    resultsDiv.innerHTML = '';
    
    predictions.forEach((prediction, index) => {
        const resultItem = document.createElement('div');
        resultItem.className = 'result-item';
        
        const name = prediction.className;
        const score = (prediction.probability * 100).toFixed(2);
        
        resultItem.innerHTML = `
            <div class="result-name">${index + 1}. ${name}</div>
            <div class="result-score">置信度: ${score}%</div>
        `;
        
        resultsDiv.appendChild(resultItem);
    });
}
